

<div class="h-captcha" data-theme="{{$theme_captcha ?? config('captcha.connection.default_theme')}}" data-sitekey="{{config("$config_root.hcaptcha.SECURITY_HCAPTCHA_SITE_KEY")}}"></div>


<script src="https://js.hcaptcha.com/1/api.js" async defer></script>
